module.exports = {
  shopierApiKey: process.env.SHOPIER_API_KEY || "test-key",
  shopierSecret: process.env.SHOPIER_SECRET || "test-secret"
};